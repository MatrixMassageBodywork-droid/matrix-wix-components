from pathlib import Path
import re, json, html

p = Path(__file__).parent
src = p.parent / 'matrix-deep-tissue-preview/dist'
urls = {
    'assets/stone-linen.png': 'https://static.wixstatic.com/media/e4cc43_d9fcbe76f8504e7ca8d602b1d8abba6b~mv2.png',
    'assets/teal-stillness.png': 'https://static.wixstatic.com/media/e4cc43_c7a233b803f1432a85043a969159ff69~mv2.png',
    'assets/linen-oil.png': 'https://static.wixstatic.com/media/e4cc43_cf5e7848046e45bfa3f86175b3b646b7~mv2.png',
    'assets/matrix-bodywork-approved.jpg': 'https://static.wixstatic.com/media/e4cc43_c35a32fb07bc4445bb822ed185350e25~mv2.jpg'
}
body = (src / 'page.html').read_text()
for a, b in urls.items():
    body = body.replace(a, b)
css = (src / 'style.css').read_text().replace('Cormorant Garamond', 'MatrixM2Cormorant').replace('Montserrat', 'MatrixM2Montserrat')
# Prefix every local component selector, including selectors within media rules.
css = re.sub(r'(^|[{}])([^{}]+)\{', lambda m: m.group(1) + ','.join(x if x.lstrip().startswith(('@', '.matrix-m2')) else '.matrix-m2 ' + x.strip() for x in m.group(2).split(',')) + '{', css)
fonts = ''
for i in range(4):
    f = next((p / 'assets').glob(f'matrix-m2-font-{i}-*.woff'))
    family = 'MatrixM2Cormorant' if i < 2 else 'MatrixM2Montserrat'
    weight = 400 if i % 2 == 0 else 500
    fonts += f"@font-face{{font-family:'{family}';font-style:normal;font-weight:{weight};font-display:swap;src:url('https://cdn.jsdelivr.net/gh/MatrixMassageBodywork-droid/matrix-wix-components@main/pages/massage/deep-tissue/assets/{f.name}') format('woff')}}\n"
css = fonts + 'matrix-deep-tissue-page{display:block;height:auto!important;min-height:0!important}\n' + css
renderer = '''/* Matrix M2 approved body, 2026-11-05. Page-local; no header/footer or head changes. */
(() => {
  const html = __HTML__;
  const css = __CSS__;
  class MatrixDeepTissue extends HTMLElement {
    connectedCallback() {
      if (this.dataset.matrixMounted === 'true') return;
      this.innerHTML = '<style>' + css + '</style>' + html;
      this.style.display = 'block';
      this.style.height = 'auto';
      this.dataset.matrixMounted = 'true';
      this.dispatchEvent(new CustomEvent('matrix-ready', { detail: { version: 'M2-approved-2026-11-05-v2' } }));
    }
  }
  if (!customElements.get('matrix-deep-tissue-page')) customElements.define('matrix-deep-tissue-page', MatrixDeepTissue);
})();
'''.replace('__HTML__', json.dumps(body)).replace('__CSS__', json.dumps(css))
(p / 'renderer.js').write_text(renderer)
(p / 'body.html').write_text(body)
(p / 'style.css').write_text(css)
def plain(value):
    return html.unescape(re.sub('<[^>]+>', '', value)).strip()
questions = []
for block in re.findall(r'<details[^>]*>(.*?)</details>', body, re.S):
    questions.append({'@type': 'Question', 'name': plain(re.search(r'<summary>(.*?)</summary>', block, re.S)[1]), 'acceptedAnswer': {'@type': 'Answer', 'text': plain(re.search(r'<p>(.*?)</p>', block, re.S)[1])}})
(p / 'faq-schema.json').write_text(json.dumps({'@context': 'https://schema.org', '@type': 'FAQPage', 'mainEntity': questions}, indent=2))
(p / 'WIX_PAGE_CODE.js').write_text('// M2 approved Deep Tissue body. Existing native page metadata is retained.\n$w.onReady(function () {\n  $w("#matrixDeepTissuePage").seoMarkup = ' + json.dumps(body) + ';\n});\n')
(p / 'asset-map.json').write_text(json.dumps(urls, indent=2))
print({'renderer_bytes': len(renderer.encode()), 'H1': len(re.findall(r'<h1\b', body)), 'FAQ': len(questions)})
